﻿using Microsoft.AspNetCore.Mvc;
using RaceDayAuthApi.Models;

namespace RaceDayAuthApi.Controllers
{
    [ApiController]
    [Route("api/users")]
    public class UsersController : ControllerBase
    {
        private readonly List<User> _users;

        public UsersController(List<User> users)
        {
            _users = users;
        }

        [HttpGet("me")]
        public IActionResult GetProfile(int userId)
        {
            User? user = _users.FirstOrDefault(u => u.UserId == userId);

            if (user == null)
            {
                return NotFound(new
                {
                    message = "User not found."
                });
            }

            return Ok(new
            {
                userId = user.UserId,
                firstName = user.FirstName,
                lastName = user.LastName,
                email = user.Email,
                role = user.Role
            });
        }
    }
}