﻿using Microsoft.AspNetCore.Mvc;
using RaceDayAuthApi.DTOs;
using RaceDayAuthApi.Models;

namespace RaceDayAuthApi.Controllers
{
    [ApiController]
    [Route("api/auth")]
    public class AuthController : ControllerBase
    {
        private readonly List<User> _users;

        public AuthController(List<User> users)
        {
            _users = users;
        }

        [HttpPost("register")]
        public IActionResult Register(RegisterRequest request)
        {
            // Check if the role is valid
            if (request.Role != "Participant" && request.Role != "Organiser")
            {
                return BadRequest(new
                {
                    message = "Role must be Participant or Organiser."
                });
            }
            // Check if the email already exists
            bool emailExists = _users.Any(u =>
                u.Email.Equals(request.Email, StringComparison.OrdinalIgnoreCase));

            if (emailExists)
            {
                return BadRequest(new
                {
                    message = "A user with this email already exists."
                });
            }

            // Create a new user
            User newUser = new User
            {
                UserId = _users.Count + 1,
                FirstName = request.FirstName,
                LastName = request.LastName,
                Email = request.Email,
                Password = request.Password,
                Role = request.Role
            };

            // Add user to the in-memory list
            _users.Add(newUser);

            return StatusCode(201, new
            {
                message = "Registration successful.",
                userId = newUser.UserId,
                firstName = newUser.FirstName,
                lastName = newUser.LastName,
                email = newUser.Email,
                role = newUser.Role
            });
        }

        [HttpPost("login")]
        public IActionResult Login(LoginRequest request)
        {
            // Find the user by email
            User? user = _users.FirstOrDefault(u =>
                u.Email.Equals(request.Email, StringComparison.OrdinalIgnoreCase));

            // Check if the user exists
            if (user == null)
            {
                return Unauthorized(new
                {
                    message = "Invalid email or password."
                });
            }

            // Check the password
            if (user.Password != request.Password)
            {
                return Unauthorized(new
                {
                    message = "Invalid email or password."
                });
            }

            // Login successful
            return Ok(new
            {
                message = "Login successful.",
                userId = user.UserId,
                firstName = user.FirstName,
                lastName = user.LastName,
                email = user.Email,
                role = user.Role
            });
        }
    }
}